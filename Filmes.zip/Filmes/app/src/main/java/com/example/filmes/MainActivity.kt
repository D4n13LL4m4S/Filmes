package com.example.filmes

import android.os.Bundle
import android.view.LayoutInflater
import android.widget.EditText
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.filmes.model.Filme
import com.google.android.material.floatingactionbutton.FloatingActionButton

class MainActivity : AppCompatActivity() {
    private val filmes = mutableListOf<Filme>()
    private lateinit var adapter: FilmeAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val recyclerView = findViewById<RecyclerView>(R.id.recyclerView)
        val fabAdd = findViewById<FloatingActionButton>(R.id.fabAdd)

        recyclerView.layoutManager = LinearLayoutManager(this)
        adapter = FilmeAdapter(filmes)
        recyclerView.adapter = adapter

        // Adicionar filmes iniciais (opcional)
        filmes.add(Filme("Filme Exemplo", "Diretor Exemplo"))
        adapter.notifyDataSetChanged()

        fabAdd.setOnClickListener {
            mostrarDialogoAdicionarFilme()
        }
    }

    private fun mostrarDialogoAdicionarFilme() {
        val dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_adicionar_filme, null)
        val editTitulo = dialogView.findViewById<EditText>(R.id.editTitulo)
        val editDiretor = dialogView.findViewById<EditText>(R.id.editDiretor)

        AlertDialog.Builder(this)
            .setTitle("Adicionar Filme")
            .setView(dialogView)
            .setPositiveButton("Adicionar") { _, _ ->
                val titulo = editTitulo.text.toString().trim()
                val diretor = editDiretor.text.toString().trim()
                if (titulo.isNotEmpty() && diretor.isNotEmpty()) {
                    val filme = Filme(titulo, diretor)
                    adapter.addFilme(filme)
                } else {
                    android.widget.Toast.makeText(this, "Preencha todos os campos", android.widget.Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }
}