package com.example.filmes.model

data class Filme(val titulo: String, val diretor: String)
