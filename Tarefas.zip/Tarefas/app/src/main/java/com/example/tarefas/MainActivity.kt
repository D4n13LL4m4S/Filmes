package com.example.tarefas

import android.os.Bundle
import android.view.LayoutInflater
import android.widget.Button
import android.widget.EditText
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.tarefas.model.Tarefa
import com.google.android.material.floatingactionbutton.FloatingActionButton

class MainActivity : AppCompatActivity() {
    private val tarefas = mutableListOf<Tarefa>()
    private lateinit var adapter: TarefaAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val recyclerView = findViewById<RecyclerView>(R.id.recyclerView)
        val fabAdd = findViewById<FloatingActionButton>(R.id.fabAdd)

        recyclerView.layoutManager = LinearLayoutManager(this)
        adapter = TarefaAdapter(tarefas)
        recyclerView.adapter = adapter

        // Adicionar tarefas iniciais (opcional)
        tarefas.add(Tarefa("Tarefa Exemplo", "Descrição Exemplo"))
        adapter.notifyDataSetChanged()

        fabAdd.setOnClickListener {
            mostrarDialogoAdicionarTarefa()
        }
    }

    private fun mostrarDialogoAdicionarTarefa() {
        val dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_adicionar_tarefa, null)
        val editNome = dialogView.findViewById<EditText>(R.id.editNome)
        val editDescricao = dialogView.findViewById<EditText>(R.id.editDescricao)

        AlertDialog.Builder(this)
            .setTitle("Adicionar Tarefa")
            .setView(dialogView)
            .setPositiveButton("Adicionar") { _, _ ->
                val nome = editNome.text.toString().trim()
                val descricao = editDescricao.text.toString().trim()
                if (nome.isNotEmpty() && descricao.isNotEmpty()) {
                    val tarefa = Tarefa(nome, descricao)
                    adapter.addTarefa(tarefa)
                } else {
                    android.widget.Toast.makeText(this, "Preencha todos os campos", android.widget.Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }
}