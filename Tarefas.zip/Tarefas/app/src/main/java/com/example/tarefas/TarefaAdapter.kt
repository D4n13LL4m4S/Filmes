package com.example.tarefas

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.tarefas.model.Tarefa

class TarefaAdapter(private val tarefas: MutableList<Tarefa>) : RecyclerView.Adapter<TarefaAdapter.TarefaViewHolder>() {

    class TarefaViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val tvNome: TextView = itemView.findViewById(R.id.tvNome)
        val tvDescricao: TextView = itemView.findViewById(R.id.tvDescricao)
        val btnConcluir: Button = itemView.findViewById(R.id.btnConcluir)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TarefaViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_tarefa, parent, false)
        return TarefaViewHolder(view)
    }

    override fun onBindViewHolder(holder: TarefaViewHolder, position: Int) {
        val tarefa = tarefas[position]
        holder.tvNome.text = tarefa.nome
        holder.tvDescricao.text = "Descrição: ${tarefa.descricao}"
        holder.btnConcluir.text = if (tarefa.concluida) "Concluída" else "Marcar como Concluída"
        holder.btnConcluir.setOnClickListener {
            tarefa.concluida = !tarefa.concluida
            notifyItemChanged(position)
        }
    }

    override fun getItemCount(): Int = tarefas.size

    fun addTarefa(tarefa: Tarefa) {
        tarefas.add(tarefa)
        notifyItemInserted(tarefas.size - 1)
    }
}